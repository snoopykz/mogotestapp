<div class="jumbotron">
    <h1>Welcome to <span class="zf-green">Zend Framework</span></h1>

    <p>
        Congratulations! You have successfully installed the
        <a href="https://github.com/zendframework/ZendSkeletonApplication" target="_blank">ZF Skeleton Application</a>.
        You are currently running Zend Framework version <?= \Application\Module::VERSION ?>.
        This skeleton can serve as a simple starting point for you to begin
        building your application on ZF.
    </p>

    <p><a class="btn btn-success btn-lg" href="https://github.com/zendframework/zendframework" target="_blank">Fork Zend Framework on GitHub &raquo;</a></p>
</div>

<div class="row">

    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Follow Development</h3>
            </div>
            <div class="panel-body">
                <p>
                    Zend Framework is under active development. If you are
                    interested in following the development of ZF, you can check
                    <a href="http://framework.zend.com/blog/">ZF dev blog</a>,
                    and <a href="https://github.com/issues?utf8=%E2%9C%93&amp;q=is:issue+org:zendframework">ZF issue tracker</a>
                    (link requires a GitHub account). This is a great resource
                    for staying up to date with the latest developments!
                </p>

                <p><a class="btn btn-success pull-right" href="http://framework.zend.com/" target="_blank">ZF Development Portal &raquo;</a></p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Discover Modules</h3>
            </div>
            <div class="panel-body">
                <p>
                    The community is working on developing a community site to
                    serve as a repository and gallery for ZF modules. The
                    project is available <a href="https://github.com/zendframework/modules.zendframework.com">on GitHub</a>.
                    The site is currently live and currently contains a list of
                    some of the modules already available for ZF.
                </p>

                <p><a class="btn btn-success pull-right" href="http://modules.zendframework.com/" target="_blank">Explore ZF Modules &raquo;</a></p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Help &amp; Support</h3>
            </div>
            <div class="panel-body">
                <p>
                    If you need any help or support while developing with ZF,
                    you may reach us via IRC: <a href="irc://irc.freenode.net/zftalk">#zftalk on Freenode</a>.
                    We'd love to hear any questions or feedback you may have
                    regarding this release. Alternatively, you may subscribe
                    and post questions to the <a href="http://framework.zend.com/archives/">mailing lists</a>.
                </p>

                <p><a class="btn btn-success pull-right" href="http://webchat.freenode.net?channels=zftalk" target="_blank">Ping us on IRC &raquo;</a></p>
            </div>
        </div>
    </div>
</div>
